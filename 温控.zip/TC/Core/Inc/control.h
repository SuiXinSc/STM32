#ifndef __CONTROL_H_
#define __CONTROL_H_

#include "main.h"
#include "math.h"

void PID_Control(double Now,double Set);

#endif
